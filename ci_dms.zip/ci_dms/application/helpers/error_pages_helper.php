<?php
function load_404(){
    redirect(base_url().'pagenotfound');

}