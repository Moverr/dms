<?php 
/*
#Author: Cengkuru Micheal
9/12/14
11:29 PM
*/
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config['site_name'] = 'Prototype';//name of website
define('NUM_OF_ROWS_PER_PAGE', "25");
define('FACEBOOK','https://www.facebook.com/cengkuru');
define('TWITTER','https://twitter.com/cengkurumichael');
define('GOOGLE_PLUS','https://plus.google.com/+CengkuruMichael87/posts');
define('SITE_NAME','www.cengkuru.com');
define('SITE_ADDRESS','p.o box 27223 Kampala');
define('SITE_EMAIL','info@cengkuru.com');
define('SITE_EMAIL_2', 'mcengkuru@gmail.com');
define('SITE_TEL', '+256 0775957998');
define('SITE_TEL_2', '+256 0753044007');
define('SITE_OWNER', 'Cengkuru Michael');
define('SITE_OWNER_TITLE', 'Web Developer');
define('IMAGES_NAME',str_replace('.','_',SITE_NAME).time());

 